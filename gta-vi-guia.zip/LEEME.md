# GTA VI Guía
Publicar: Cloudflare Pages > Create project > Direct Upload (sube esta carpeta) o conecta un repo. Sin comando de build; directorio de salida: la raíz.
Añadir contenido: edita assets/data.js (instrucciones al principio del archivo). Publica solo datos comprobados en el juego.
Antes de publicar: cambia tudominio.com en index.html, robots.txt y sitemap.xml.
Mapa: las posiciones son aproximadas; ajusta x/y en data.js (lienzo de 1000x640) cuando tengas el mapa real.
