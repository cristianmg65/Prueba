/* AÑADIR CONTENIDO: copia una línea de items y cambia los campos.
   cat: trucos | vehiculos | armas | dinero | secretos | guias | novedades
   Campos: title, text (obligatorios); code, platform, tags[], date 'AAAA-MM-DD' (opcionales).
   Ejemplo: {cat:'trucos',title:'Nombre',text:'Qué hace',code:'Código o botones',platform:'PS5',tags:['vida']},
   Publica solo lo comprobado en el juego. */
window.GTA={
items:[
{cat:'novedades',date:'2025-11-06',title:'Rockstar retrasa GTA VI al 19 de noviembre de 2026',text:'Rockstar anunció que el juego saldrá el jueves 19 de noviembre de 2026, después de haber fijado antes el 26 de mayo de 2026.',tags:['lanzamiento']},
{cat:'novedades',date:'2026-02-04',title:'Take-Two reafirma el 19 de noviembre',text:'La publicadora Take-Two Interactive confirmó de nuevo esa fecha como objetivo de lanzamiento.',tags:['lanzamiento']},
{cat:'novedades',date:'2025-05-02',title:'Primer retraso: el juego pasa al 26 de mayo de 2026',text:'Rockstar movió la salida desde la ventana de 2025 a una primera fecha concreta, que después volvió a cambiar.',tags:['retraso']},
{cat:'novedades',date:'2023-12-05',title:'Se publica el primer tráiler',text:'El tráiler 1 presentó el regreso a Vice City y anunció una salida en 2025.',tags:['tráiler']},
{cat:'novedades',title:'Plataformas confirmadas',text:'GTA VI sale en PlayStation 5 y Xbox Series X|S. No se ha anunciado versión para PC.',platform:'PS5 / Xbox Series',tags:['plataformas']},
{cat:'secretos',title:'Los protagonistas son Lucia y Jason',text:'El primer tráiler presenta a Lucia y Jason como pareja protagonista.',tags:['personajes']},
{cat:'secretos',title:'Leonida y el regreso a Vice City',text:'El juego se ambienta en el estado ficticio de Leonida, con Vice City como gran ciudad.',tags:['ambientación']},
{cat:'secretos',title:'Doce años desde GTA V',text:'La entrega anterior de la saga principal, GTA V, salió en 2013.',tags:['saga']}
],
map:[
{n:'Vice City',x:690,y:300,d:'Gran ciudad costera del estado de Leonida.'},
{n:'Leonida Keys',x:380,y:575,d:'Cadena de islas al sur del estado.'},
{n:'Grassrivers',x:520,y:400,d:'Región de humedales en el interior.'},
{n:'Port Gellhorn',x:270,y:250,d:'Zona portuaria del estado.'},
{n:'Ambrosia',x:480,y:200,d:'Región del interior de Leonida.'},
{n:'Mount Kalaga',x:600,y:120,d:'Zona montañosa en el norte.'}
]};
